| `Version` | `Update Notes`         |
|-----------|------------------------|
| 1.0.1     | - Fix toggling back on |
| 1.0.0     | - Initial Release      |